package com.hexaware.mainpkg;

import java.util.ArrayList;
import java.util.logging.Logger;
import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.InsufficientFundsException;
import com.hexaware.myexceptions.NegativeAmountException;

public class MainMod {
    private static final Logger LOGGER = Logger.getLogger(MainMod.class.getName());

    public static void main(String[] args) throws InsufficientFundsException, AccountNumberInvalidException,
            NegativeAmountException {

        // TODO Auto-generated method stub
        BankAccount obj1 = new BankAccount("Sachin", "Current", 80000.50);
        BankAccount obj2 = new BankAccount("Nisha", "Savings", 20000.50);
        BankAccount obj3 = new BankAccount("Roshid", "Current", 35000.50);

        ArrayList<BankAccount> myList = new ArrayList<>();
        myList.add(obj1);
        myList.add(obj2);
        myList.add(obj3);

        Bank myBank = new Bank("ICICI", myList);

        ServiceProviderImpl myServiceObj = new ServiceProviderImpl(myBank);

        LOGGER.info("Starting the MainMod program.");
        int accountNumber = 1111;
        try {
            LOGGER.info("Checking balance for account: " + accountNumber);
            System.out.println("Balance of account " + accountNumber + " : " + myServiceObj.checkBalance(accountNumber));
        }catch (AccountNumberInvalidException e) {
            
            LOGGER.warning("AccountNumberInvalidException: " + e.getMessage());
            throw new AccountNumberInvalidException("Account number is invalid");}
           
        try {
            LOGGER.info("Depositing -5000.50 to account: " + accountNumber);
            System.out.println("Status of deposit: " + myServiceObj.deposit(accountNumber, -5000.50));
        }catch (NegativeAmountException e) {
        
        LOGGER.warning("NegativeAmountException: " + e.getMessage());
        e.printStackTrace();}
            
        try {
            LOGGER.info("Checking balance for account: " + accountNumber);
            System.out.println("Balance of account " + accountNumber + " : " + myServiceObj.checkBalance(accountNumber));
        }
         catch (AccountNumberInvalidException e) {
            
            LOGGER.warning("AccountNumberInvalidException: " + e.getMessage());
            throw new AccountNumberInvalidException("Account number is invalid");
        } try {
            LOGGER.info("Depositing -5000.50 to account: " + accountNumber);
            System.out.println("Status of deposit: " + myServiceObj.deposit(accountNumber, 5000.50));
        }catch (NegativeAmountException e) {
        
        LOGGER.warning("NegativeAmountException: " + e.getMessage());
        e.printStackTrace();}
            
        try {
            LOGGER.info("Checking balance for account: " + accountNumber);
            System.out.println("Balance of account " + accountNumber + " : " + myServiceObj.checkBalance(accountNumber));
        }
         catch (AccountNumberInvalidException e) {
            
            LOGGER.warning("AccountNumberInvalidException: " + e.getMessage());
            throw new AccountNumberInvalidException("Account number is invalid");
        } 
        finally {
            
            LOGGER.info("Final details of the bank: " + myBank);
        }
    }
}