package com.hexaware.myexceptions;
public class AccountNumberInvalidException extends Exception{
public AccountNumberInvalidException (String message) {
	super(message+"Account number is invalid");
}
}
