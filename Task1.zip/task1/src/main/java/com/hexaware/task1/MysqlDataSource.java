package com.hexaware.task1;
import org.springframework.stereotype.Component;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySQL")
@Primary
public class MysqlDataSource implements DataSource {

    @Override
    public void returnConnection() {
        System.out.println("MySQL database ");
    }
}
