package com.hexaware.task1;

public interface DataSource {
	
	public void returnConnection();


}
