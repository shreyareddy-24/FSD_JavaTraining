package com.hexaware.task1;
import org.springframework.stereotype.Component;

@Component("postgeSQLDatabase")
public class PostgreSqlDataSource implements DataSource {
    public void returnConnection() {
        System.out.println("Postge Databse");
    }
}
