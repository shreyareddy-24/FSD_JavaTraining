package com.hexaware.task1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService {

    DataSource obj=null;

    @Autowired
    public EmailService(DataSource t) {
        this.obj=t;
        
    }

    public void sendEmail() {
        obj.returnConnection();
    }
}
