package com.hexaware.demo1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Client {
	public static void main(String args[]) {
		String message="message to be delivered";
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		MessageService smsService = context.getBean(SmsService.class);
        MessageService emailService = context.getBean(EmailService.class);
        MessageSender sender1 = new MessageSender(emailService, smsService);
        sender1.sendMessage(message, "email");
        sender1.sendMessage(message,"sms");

	}

}
