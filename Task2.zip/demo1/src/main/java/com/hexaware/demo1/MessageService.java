package com.hexaware.demo1;

interface MessageService {
    void sendMessage(String message);
}
