package com.hexaware.demo1;

import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService implements MessageService {

	@Override
	public void sendMessage(String message) {
		// TODO Auto-generated method stub
		System.out.println(message);
	}
	

}
