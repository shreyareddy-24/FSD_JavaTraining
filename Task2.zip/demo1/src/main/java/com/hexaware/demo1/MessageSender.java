package com.hexaware.demo1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("messageSender")
public class MessageSender {
    private final MessageService smsService;
    private final MessageService emailService;

    @Autowired
    public MessageSender(@Qualifier("smsService") MessageService smsService,
                         @Qualifier("emailService") MessageService emailService) {
        this.smsService = smsService;
        this.emailService = emailService;
    }

    public void sendMessage(String message, String type) {
        if ("email".equals(type)) {
            this.emailService.sendMessage(message);
        } else {
            this.smsService.sendMessage(message);
        }
    }
}
