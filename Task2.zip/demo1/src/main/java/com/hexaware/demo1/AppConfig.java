package com.hexaware.demo1;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.hexaware.demo1")

public class AppConfig {
	@Bean(name = "smsService")
    public MessageService smsService() {
        return new SmsService();
    }

    @Bean(name = "emailService")
    public MessageService emailService() {
        return new EmailService();
    }
}
